package org.crazyit.act.aw.service;

import java.util.List;

import org.crazyit.act.aw.entity.Person;

public interface PersonService {

    List<Person> listPersons();
}
