package org.crazyit.act.aw.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.crazyit.act.aw.dao.PersonDao;
import org.crazyit.act.aw.entity.Person;

public class PersonDaoImpl implements PersonDao {

    @PersistenceContext
    private EntityManager entityManager;

    public List<Person> list() {
        return entityManager.createQuery("from Person").getResultList();
    }

}
