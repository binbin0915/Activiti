package org.crazyit.act;

import feign.Feign;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;

public class TestMain {

    public static void main(String[] args) {
        // 获取服务接口
        PersonClient personClient = Feign.builder()
                .decoder(new GsonDecoder())
                .target(PersonClient.class, "http://localhost:8080/");
        // 请求接口
        Person p = personClient.getPerson(3);
        System.out.println(p.getId() + "---" + p.getName());
    }

}
