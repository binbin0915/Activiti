package org.crazyit.act;

import feign.Param;
import feign.RequestLine;

public interface PersonClient {

    @RequestLine("GET /person/{id}")
    Person getPerson(@Param("id") Integer id);
}
