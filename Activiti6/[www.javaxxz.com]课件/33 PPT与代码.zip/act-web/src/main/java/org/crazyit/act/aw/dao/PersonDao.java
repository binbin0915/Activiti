package org.crazyit.act.aw.dao;

import java.util.List;

import org.crazyit.act.aw.entity.Person;

public interface PersonDao {

    List<Person> list();
}
